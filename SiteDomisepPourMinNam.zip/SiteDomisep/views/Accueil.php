<?php include("General.php") ?>

<!DOCTYPE html>

<html>
<head>
	<title>Accueil</title>
		<link rel="stylesheet" href="design/Accueil.css" />

</head>
<body>
	<div class="presentation">
		<div class="texte"><h1 class="titre">Sécurisep</h1>
			<h2 class="secondTitre">Connectez votre maison </br> et </br>entrez dans le futur</h2></div>
	</div>

	<div class="Apropos">
		<h1>Venez souscrire à notre offre</h1>

	<div class="PresentationGris">
		<img class="img" src="image/img1.png" alt="img1"/>
		<p> Inscrivez-très facilement et commandez vos capteurs pour contrôler votre maison. Vous les ajoutez facilement à votre compte.</p>
	</div>

	<div class="PresentationBlanc">
		<img class="img" src="image/img2.png" alt="img1"/>
		<p> Contrôler vos appareils connectés grâce à la page 'Maison' où tous vos appreils apparaissent. Un simple clic vous permet d'allumer ou éteindre une lampe, ou encore règler votre chauffage.</p>
		<br><br>
	</div>

	<div class="PresentationGris">
		<img class="img" src="image/img3.png" alt="img1"/>
		<p> Le forum permet de poser toutes les questions que vous pouvez vous poser. La communauté vous répondra avec plaisir et certains auront peut être rencontré le même problème que vous.</p>
		<br><br>
	</div>
</div>
<br><br></body>
</html>