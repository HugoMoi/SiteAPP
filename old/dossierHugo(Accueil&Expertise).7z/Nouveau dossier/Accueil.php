<?php include("General.php") ?>

<!DOCTYPE html>

<html>
<head>
	<title>Accueil</title>
		<link rel="stylesheet" href="../Style/Accueil.css" />
</head>
<body>
	<div class="presentation">
		<div class="texte"><h1 class="tire">Sécurisep</h1>
			<h2 class="secondTitre">Connectez votre maison </br> et </br>entrez dans le futur</h2></div>
	</div>

	<div class="Apropos">
		<h1>Venez souscrire à notre offre</h1>
	</div>
</body>
</html>