-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  mar. 15 jan. 2019 à 16:37
-- Version du serveur :  5.7.23
-- Version de PHP :  7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `espace_membre`
--

-- --------------------------------------------------------

--
-- Structure de la table `membres`
--

DROP TABLE IF EXISTS `membres`;
CREATE TABLE IF NOT EXISTS `membres` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pseudo` varchar(255) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `motdepasse` text NOT NULL,
  `confirmkey` varchar(255) NOT NULL,
  `confirme` int(1) NOT NULL DEFAULT '0',
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `adresse` text NOT NULL,
  `codepostal` int(11) NOT NULL,
  `ville` text NOT NULL,
  `admin` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `membres`
--

INSERT INTO `membres` (`id`, `pseudo`, `mail`, `motdepasse`, `confirmkey`, `confirme`, `nom`, `prenom`, `adresse`, `codepostal`, `ville`, `admin`) VALUES
(28, 'hjr', 'hashleyjr@gmail.com', 'fde90d3e864627939f2fbbd87df25364b9a7aa6c', '43748383363355', 0, '', '', '', 0, '', 0),
(39, 'MinhNam', 'nguyen.minhnam@hotmail.fr', '948671729b6bec289730e25186aac08f7537d108', '96503605454031', 1, 'Nguyen', 'MinhNam', '', 0, '', 1),
(34, 'hugo', 'hugo.gh@gmail.com', '782dd27ea8e3b4f4095ffa38eeb4d20b59069077', '87991336415118', 1, 'Ghesquiere', 'hugo', '', 0, '', 1),
(35, 'moi', 'fgfgf@hj.hg', '782dd27ea8e3b4f4095ffa38eeb4d20b59069077', '15212935311390', 1, 'fbgg', 'hig', '', 0, '', 0),
(36, 'azer', 'azer@gh.fg', '782dd27ea8e3b4f4095ffa38eeb4d20b59069077', '34447931529142', 0, 'azer', 'azer', '', 0, '', 0),
(38, 'gggg', 'fhg@gh.df', '782dd27ea8e3b4f4095ffa38eeb4d20b59069077', '35785474548927', 0, 'pngggg', 'ggg', '', 0, '', 0),
(41, 'Minh', 'yo@hotmail.fr', '948671729b6bec289730e25186aac08f7537d108', '28615761629099', 1, 'Nguyen', 'Minh', '5 rue oscar Niemeyer', 78280, 'Guyancourt', 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
